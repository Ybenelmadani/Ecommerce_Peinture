import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Container from "../components/layout/Container";
import Button from "../components/ui/Button";
import ProductCard from "../components/product/ProductCard";
import { CatalogAPI } from "../api/catalog";

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    CatalogAPI.products().then(data => setProducts(data.slice(0, 8))).catch(()=>{});
  }, []);

  return (
    <>
      <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 text-white">
        <Container className="py-16 md:py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="text-xs uppercase tracking-[0.3em] opacity-80">New season</div>
            <h1 className="mt-3 text-4xl md:text-5xl font-black leading-tight">
              Premium art supplies, <span className="text-slate-200">simple checkout</span>.
            </h1>
            <p className="mt-4 text-slate-200">
              Browse products, choose variants, add to cart, checkout — powered by Laravel API.
            </p>
            <div className="mt-8 flex gap-3">
              <Link to="/products"><Button>Shop now</Button></Link>
              <Link to="/orders"><Button variant="soft">My orders</Button></Link>
            </div>
          </div>

          <div className="rounded-3xl border border-white/15 bg-white/10 p-4 shadow-xl">
            <img
              className="rounded-2xl w-full h-[320px] object-cover"
              src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=1400"
              alt="Hero"
            />
          </div>
        </Container>
      </section>

      <Container className="py-12">
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-xl md:text-2xl font-black">Featured products</h2>
          <Link to="/products" className="text-sm font-semibold text-slate-700 hover:text-slate-900">
            View all →
          </Link>
        </div>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {products.map(p => <ProductCard key={p.id} p={p} />)}
        </div>
      </Container>
    </>
  );
}