import React, { useEffect, useState } from "react";
import { http } from "../api/http";
import { useAuth } from "../context/AuthContext";

export default function MyOrders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await http.get("/orders");
        setOrders(res.data?.data || res.data || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (!user) {
    return <div className="p-6 text-slate-600">Please login.</div>;
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-black">My Orders</h1>

      {loading ? (
        <div className="mt-6 text-slate-600">Loading…</div>
      ) : orders.length === 0 ? (
        <div className="mt-6 p-6 rounded-2xl border border-slate-200 text-slate-600">
          No orders yet.
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="rounded-2xl border border-slate-200 p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-black">Order #{o.id}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    {o.created_at}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Total</div>
                  <div className="text-lg font-black">
                    {Number(o.total_amount || o.total || 0).toFixed(2)} USD
                  </div>
                </div>
              </div>

              {o.items?.length ? (
                <div className="mt-4 text-sm text-slate-700">
                  <div className="font-semibold mb-2">Items</div>
                  <ul className="list-disc pl-5 space-y-1">
                    {o.items.map((it) => (
                      <li key={it.id}>
                        {it.product_name || it.product?.name || "Product"} × {it.quantity}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}