import axios from "axios";

export const http = axios.create({
  baseURL: "http://ecommerce_back-end.test/api",
  headers: { Accept: "application/json" },
});

// Ajoute automatiquement Authorization: Bearer <token> à chaque requête
http.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});