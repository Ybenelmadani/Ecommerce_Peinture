import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, ShoppingBag } from "lucide-react";
import { useCart } from "../../context/CartContext";
import { useAuth } from "../../context/AuthContext";

export default function Header() {
  const nav = useNavigate();

  const { items, setOpen } = useCart();
  const { user, logout } = useAuth();

  const [q, setQ] = useState("");

  const goSearch = () => {
    const term = q.trim();
    nav(`/products?q=${encodeURIComponent(term)}`);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-6">

        {/* Logo */}
        <Link
          to="/"
          className="text-xl font-black tracking-tight text-slate-900"
        >
          ArtStore
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <Link to="/products" className="hover:text-slate-900">
            Shop
          </Link>
        </nav>

        {/* Search */}
        <div className="ml-auto hidden md:flex items-center w-[400px] relative">
          <input
            type="text"
            placeholder="Search products..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") goSearch();
            }}
            className="w-full rounded-xl border border-slate-200 px-4 py-2 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <button
            onClick={goSearch}
            className="absolute right-2 p-2 rounded-lg hover:bg-slate-100"
          >
            <Search size={18} className="text-slate-400" />
          </button>
        </div>

        {/* Auth */}
        <div className="flex items-center gap-4 text-sm font-semibold">

          {user ? (
            <>
              <span className="text-slate-600 hidden md:block">
                Hello, {user.name}
              </span>

              <button
                onClick={logout}
                className="hover:underline"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:underline">
                Login
              </Link>

              <Link to="/register" className="hover:underline">
                Register
              </Link>
            </>
          )}

          {/* Cart */}
          <button
            onClick={() => setOpen(true)}
            className="relative p-2 rounded-xl hover:bg-slate-100"
          >
            <ShoppingBag size={22} />

            {items.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {items.length}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}