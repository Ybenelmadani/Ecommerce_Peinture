import React from "react";
import Container from "./Container";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white">
      <Container className="py-10 grid grid-cols-1 md:grid-cols-4 gap-8 text-sm">
        <div>
          <div className="text-lg font-black">ArtMart</div>
          <p className="mt-2 text-slate-600">Modern art supplies shop demo (React + Laravel API).</p>
        </div>
        <div>
          <div className="font-semibold">Shop</div>
          <ul className="mt-3 space-y-2 text-slate-600">
            <li>Categories</li>
            <li>Brands</li>
            <li>New In</li>
          </ul>
        </div>
        <div>
          <div className="font-semibold">Help</div>
          <ul className="mt-3 space-y-2 text-slate-600">
            <li>Delivery</li>
            <li>Returns</li>
            <li>Contact</li>
          </ul>
        </div>
        <div>
          <div className="font-semibold">Legal</div>
          <ul className="mt-3 space-y-2 text-slate-600">
            <li>Privacy</li>
            <li>Terms</li>
          </ul>
        </div>
      </Container>
      <div className="border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} ArtMart
      </div>
    </footer>
  );
}