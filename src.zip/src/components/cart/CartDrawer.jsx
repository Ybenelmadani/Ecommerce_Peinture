import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import Button from "../ui/Button";
import Price from "../ui/Price";
import { useCart } from "../../context/CartContext";

export default function CartDrawer() {
  const nav = useNavigate();
  const { open, setOpen, items, total, updateQty, remove, loading } = useCart();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100]">
      {/* overlay */}
      <div
        className="absolute inset-0 bg-black/40"
        onClick={() => setOpen(false)}
      />

      {/* panel */}
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl border-l border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div className="text-lg font-black">Your cart</div>
            <div className="text-xs text-slate-500">Demo user_id=1</div>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="p-2 rounded-xl hover:bg-slate-100"
            aria-label="Close cart"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          {loading ? (
            <div className="text-slate-500">Loading…</div>
          ) : items.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 p-6 text-center text-slate-600">
              Cart is empty.
              <div className="mt-4">
                <Button onClick={() => setOpen(false)}>Continue shopping</Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {items.map((it) => {
                const p = it.variant?.product;
                const img =
                  p?.images?.find((i) => i.is_main)?.image_path ||
                  p?.images?.[0]?.image_path;

                return (
                  <div
                    key={it.id}
                    className="rounded-2xl border border-slate-200 p-3 flex gap-3"
                  >
                    <div className="w-20 h-16 rounded-xl bg-slate-100 overflow-hidden shrink-0">
                      {img ? (
                        <img
                          src={img}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      ) : null}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="font-bold truncate">
                        {p?.name || "Product"}
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        {[it.variant?.color, it.variant?.finish, it.variant?.capacity]
                          .filter(Boolean)
                          .join(" • ")}
                      </div>

                      <div className="mt-3 flex items-center gap-2">
                        <input
                          type="number"
                          min={1}
                          value={it.quantity}
                          onChange={(e) =>
                            updateQty(it.id, Math.max(1, Number(e.target.value || 1)))
                          }
                          className="w-20 rounded-xl border border-slate-200 px-3 py-2 text-sm"
                        />
                        <Button variant="ghost" onClick={() => remove(it.id)}>
                          Remove
                        </Button>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs text-slate-500">Unit</div>
                      <Price value={it.unit_price} />
                      <div className="mt-2 text-xs text-slate-500">Sub</div>
                      <div className="font-semibold">
                        {(Number(it.unit_price) * it.quantity).toFixed(2)} USD
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-600">Total</span>
            <span className="text-lg font-black">{total.toFixed(2)} USD</span>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <Link to="/cart" onClick={() => setOpen(false)}>
              <Button variant="soft" className="w-full">
                View cart
              </Button>
            </Link>
            <Button
              className="w-full"
              onClick={() => {
                setOpen(false);
                nav("/checkout");
              }}
              disabled={items.length === 0}
            >
              Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}