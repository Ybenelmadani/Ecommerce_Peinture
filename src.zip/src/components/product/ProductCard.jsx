import React from "react";
import { Link } from "react-router-dom";
import Price from "../ui/Price";
import Button from "../ui/Button";

export default function ProductCard({ p }) {
  const mainImg = p.images?.find(i => i.is_main)?.image_path || p.images?.[0]?.image_path;

  return (
    <div className="group rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm hover:shadow-md transition">
      <Link to={`/products/${p.id}`} className="block">
        <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
          {mainImg ? (
            <img src={mainImg} alt={p.name} className="h-full w-full object-cover group-hover:scale-[1.03] transition" />
          ) : (
            <div className="h-full w-full flex items-center justify-center text-slate-400 text-sm">No image</div>
          )}
        </div>
      </Link>

      <div className="p-4">
        <div className="text-xs text-slate-500">
          {p.brand?.name} • {p.category?.name}
        </div>
        <div className="mt-1 font-bold">{p.name}</div>

        {/* si ton API ne donne pas prix ici, on affiche "See variants" */}
        <div className="mt-2 text-slate-700">
          <span className="text-sm">See variants</span>
        </div>

        <div className="mt-4">
          <Link to={`/products/${p.id}`}>
            <Button variant="soft" className="w-full">View</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}